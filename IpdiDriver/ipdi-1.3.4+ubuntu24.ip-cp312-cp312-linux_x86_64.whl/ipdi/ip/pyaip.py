from ipdi.ip.aip import ui_flits, aip_init, enable_int_wrapper, Callback
import inspect

import sys
import os

class pyaip:
    __aip = None

    def __init__(self):
        pass

    def reset(self):
        self.__aip.reset()

    # def init(self, connector_name, nic_addr, port, csv_file_path):
    #     self.__aip = aip_init(connector_name, nic_addr, port, csv_file_path)
    # return self.__aip.init(connector_name)

    def version(self):
        return self.__aip.version()

    def getID(self):
        return self.__aip.getID()

    def getStatus(self):
        return self.__aip.getStatus()

    def readMem(self, confMem, amountOfData, offset):

        if type(confMem) !=  str:
            self.__aip.finish()
            printIPdIErrorAndExit('confMem should be an string')

        if amountOfData < 1:
            self.__aip.finish()
            printIPdIErrorAndExit('amountOfData parameter must be grater than 1')

        if offset < 0:
            self.__aip.finish()
            printIPdIErrorAndExit('offset parameter must be greater or equal than 0')

        flits = ui_flits(amountOfData)
        ret = self.__aip.readMem(confMem, flits, amountOfData, offset)

        if ret < 0 or ret > 0xFFFFFFFC:

            if ret == -2 or ret == -3 or ret == 0xFFFFFFFE or ret == 0xFFFFFFFE:
                printIPdIErrorAndExit(f'{confMem} does not exist')

            self.__aip.finish()
            printIPdIErrorAndExit('Cannot ReadMem')

        # dataRead.extend([0 for i in range(amountOfData)])
        dataRead = []

        for i in range(amountOfData):
            dataRead.append(flits[i])

        return dataRead

    def writeMem(self, confMem, dataWrite, amountOfData, offset):

        if type(confMem) !=  str:
            self.__aip.finish()
            printIPdIErrorAndExit('confMem should be an string')

        if not type(dataWrite) is list:
            self.__aip.finish()
            printIPdIErrorAndExit('Second argument must be a list')

        if not all(isinstance(x, int) and 0 <= x <= 0xFFFFFFFF for x in dataWrite):
            self.__aip.finish()
            printIPdIErrorAndExit('items in dataWrite must be 32 bit unsigned integers')

        if len(dataWrite) != amountOfData:
            self.__aip.finish()
            printIPdIErrorAndExit('amountOfData must be same as lenght of dataWrite')

        if amountOfData < 1:
            self.__aip.finish()
            printIPdIErrorAndExit('amountOfData parameter must be grater than 1')

        if offset < 0:
            self.__aip.finish()
            printIPdIErrorAndExit('offset parameter must be greater or equal than 0')

        flits = ui_flits(len(dataWrite))

        for i in range(len(dataWrite)):
            flits[i] = dataWrite[i]

        ret = self.__aip.writeMem(confMem, flits, amountOfData, offset)

        if ret < 0 or ret > 0xFFFFFFFC:

            if ret == -2 or ret == -3 or ret == 0xFFFFFFFE or ret == 0xFFFFFFFE:
                printIPdIErrorAndExit(f'{confMem} does not exist')

            self.__aip.finish()
            printIPdIErrorAndExit('CannotWrtiteMem')

        return len(dataWrite)

    def writeConfReg(self, confReg, dataWrite, amountOfData, offset):

        if type(confReg) !=  str:
            self.__aip.finish()
            printIPdIErrorAndExit('confReg should be an string')

        if not type(dataWrite) is list:
            self.__aip.finish()
            printIPdIErrorAndExit('Second argument must be a list')

        if not all(isinstance(x, int) and 0 <= x <= 0xFFFFFFFF for x in dataWrite):
            self.__aip.finish()
            printIPdIErrorAndExit('items in dataWrite must be 32 bit unsigned integers')

        if len(dataWrite) != amountOfData:
            self.__aip.finish()
            printIPdIErrorAndExit('amountOfData must be same as lenght of dataWrite')

        if amountOfData < 1 or amountOfData > 4:
            self.__aip.finish()
            printIPdIErrorAndExit('amountOfData parameter must be between 1 and 4')

        if offset < 0 or offset > 4:
            self.__aip.finish()
            printIPdIErrorAndExit('[offset parameter must be between 0 and 4')
            # printIPdIErrorAndExit('[offset parameter must be greater or equal than 0')

        flits = ui_flits(len(dataWrite))

        for i in range(len(dataWrite)):
            flits[i] = dataWrite[i]

        ret = self.__aip.writeConfReg(confReg, flits, amountOfData, offset)

        if ret < 0 or ret > 0xFFFFFFFC:

            if ret == -2 or ret == -3 or ret == 0xFFFFFFFE or ret == 0xFFFFFFFE:
                printIPdIErrorAndExit(f'{confMem} does not exist')

            self.__aip.finish()
            printIPdIErrorAndExit('CannotWrtiteConfReg')

        return len(dataWrite)

    def start(self):
        return self.__aip.start()

    def enableINT(self, idxINT, Callback):
        if(idxINT < 0 or idxINT > 7):
            self.__aip.finish()
            printIPdIErrorAndExit('[idxInt argument must be between 0 and 7')

        return enable_int_wrapper(self.__aip, idxINT, Callback)

    def disableINT(self, idxINT):
        if(idxINT < 0 or idxINT > 7):
            self.__aip.finish()
            printIPdIErrorAndExit('idxInt argument must be between 0 and 7')

        return self.__aip.disableINT(idxINT)

    def clearINT(self, idxINT):
        if(idxINT < 0 or idxINT > 7):
            self.__aip.finish()
            printIPdIErrorAndExit('idxInt argument must be between 0 and 7')

        return self.__aip.clearINT(idxINT)

    def getINT(self, intVector):
        if not type(intVector) is list:
            self.__aip.finish()
            printIPdIErrorAndExit('intVector must be a list')

        return self.__aip.getINT(intVector)

    def getNotifications(self, notificationsVector):
        if not type(notificationsVector) is list:
            self.__aip.finish()
            printIPdIErrorAndExit('notificationsVector must be a list')

        return self.__aip.getNotifications(notificationsVector)

    def enableNicInts(self):
        return self.__aip.enableNicInts()

    def waitForINT(self):
        return self.__aip.waitForINT()

    def finish(self):
        self.__aip.finish()


def printIPdIErrorAndExit(message):
    error_frame = inspect.currentframe().f_back
    caller_info = inspect.getframeinfo(error_frame.f_back)
    print(f'File: "{caller_info.filename}", line: {caller_info.lineno}, in {caller_info.function}')
    print(f'{caller_info.code_context[0].strip()}')
    sys.exit(f'[ERROR] {message}')


def pyaip_init(connector_name, nic_addr, port, csv_file_path):

    # Validate connector_name
    #   win: COMx
    #   lin: /dev/ttyACMx, /dev/ttyUSBx
    MAX_NIC = 255
    if ( nic_addr < 1 or nic_addr > MAX_NIC ):
        printIPdIErrorAndExit(f'nic_addr argument must be between 1 and {MAX_NIC}')

    if ( port < 0 or port > 7 ):
        printIPdIErrorAndExit(f'port argument must be between 1 and 7')
    
    if ( not os.path.exists(csv_file_path) ):
        printIPdIErrorAndExit(f'{csv_file_path} does not exists')

    aip = pyaip()

    aip._pyaip__aip = aip_init(connector_name, nic_addr, port, csv_file_path)

    if aip._pyaip__aip is not None:
        return aip
    else:
        printIPdIErrorAndExit('Cannot create pyaip object')

